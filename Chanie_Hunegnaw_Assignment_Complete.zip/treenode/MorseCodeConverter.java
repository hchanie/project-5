package treenode;
/**
 * The MorseCodeConverter class contains a static MorseCodeTree object. And it has
 * two static methods to convert the Morse code to English. One method is passed a 
 * string object (�.-.. --- ...- . / .-.. --- --- ...�). The other method is passed 
 * a file to be converted. Each method returns a string object of English characters.   
 *@author hunegnaw
 *
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class MorseCodeConverter 
{	
	private static MorseCodeTree MorseTree = new MorseCodeTree(); // an object of the MorseCodeTree class
	
	/**
	 * Constructor a default 
	 */
	public MorseCodeConverter()   {     }
	
	/**
	 * The convertToEnglish Method converts Morse code into English. 
	 * Each letter is delimited by a space (� �). Each word is delimited by a �/�.
	 * @param code - the Morse code
	 * @return result - the English translation
	 */
	public static String convertToEnglish(String code) 
	{	
		   String result = "";
	       String[] wordInCode = code.split(" / "); 
	       String[] character; 

	       // loop through the array containing all the words of a line
	       for(int count = 0; count < wordInCode.length; count++)
	       {  
	           character = wordInCode[count].split(" ");
	                for(int index = 0; index < character.length; index++)
	                {
	                	result += MorseTree.fetch(character[index]);  
	                }
	           result += " ";
	       }  
	       result = result.trim();      
	       return result;
	}

	public static String convertToEnglish(File codeFile) throws FileNotFoundException
	{
		   String result = "";
	       ArrayList<String> line = new ArrayList<String>();
	       String[] word; 
	       String[] character; 
	      
	       Scanner scanFile;
	       scanFile = new Scanner(codeFile);
	      
	       // Read each content into a String ArrayList(line by line) 
	       while (scanFile.hasNext())
	       {  
	           line.add(scanFile.nextLine());
	       }         
	       scanFile.close();
	      
	       for(int count = 0; count < line.size(); count++)
	       {
	           word = line.get(count).split(" / ");
	           for(int index = 0; index < word.length; index++)
	           {
	               character = word[index].split(" ");
	              
	               for(int i = 0; i < character.length; i++)
	               {
	            	   result += MorseTree.fetch(character[i]);  
	               }
	               result += " ";
	           }
	       }
	       result = result.trim();
	       return result;
	}
	
	 /**
	   * Returns a string with all the data in the tree in LNR order with an space in between them. 
	   * Uses the toArrayList method in MorseCodeTree. 
	   * It should return the data in this order: "h s v i f u e l r a p w j b d x n c k y t z g q m o"
	   * Note the extra space between j and b - that is because there is an empty string that is the root, 
	   * and in the LNR traversal, the root would come between the right most child of the left tree (j)
	   * and the left most child of the right tree (b). This is used for testing purposes to make
	   * sure the MorseCodeTree has been built properly
	   *
	   * @return the data in the tree in LNR order separated by a space.
	   */
	   public static String printTree()
	   {
	       ArrayList<String> temp = new ArrayList<String>();    
	       temp = MorseTree.toArrayList();	      
	       String print = "";	      
	           for(int count = 0; count < temp.size(); count ++)
	            {
	        	   print += temp.get(count) + " ";  
	            }	      
	       return print;
	   }

}

