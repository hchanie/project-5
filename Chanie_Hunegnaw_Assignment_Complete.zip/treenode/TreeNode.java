package treenode;
/**
 * This generic class is used in the MorseCodeTree classes. 
 *  The class consists of a reference to the data 
 *  and a reference to the left and right child. 
 * @author hunegnaw
 *
 * @param <T>
 */

public class TreeNode<T> 
{
	private T data;
	private TreeNode<T> leftChild;
	private TreeNode<T> rightChild;
	
	/**
	 * Constructor 
	 * @param dataNode - the data to be stored in the TreeNode
	 */
	public TreeNode(T dataNode)
	{
		this.data = dataNode;
		rightChild = leftChild = null;
	}
	
	/**
	 * Constructor that makes deep copy
	 * @param node 
	 */
	public TreeNode(TreeNode<T> node)
	{
		//new TreeNode<T>(node);
		this.data = node.data;
		if(node.leftChild != null)
			this.leftChild = new TreeNode<T>(node.leftChild);
		this.rightChild = new TreeNode<T>(node.rightChild);
	}
	
	/**
	 * The getLeftChild method
	 * @return the data on the left child
	 */
	public TreeNode<T> getLeftChild() 
	{
		return leftChild;
	}

	/**
	 * The setLeftChild method
	 * @param leftChild
	 */
	public void setLeftChild(TreeNode<T> leftChild) 
	{
		this.leftChild = leftChild;
	}

	/**
	 * The getRightChild method
	 * @return the right child data
	 */
	public TreeNode<T> getRightChild() 
	{
		return rightChild;
	}

	/**
	 * The setRightChild method 
	 * @param rightChild
	 */
	public void setRightChild(TreeNode<T> rightChild) 
	{
		this.rightChild = rightChild;
	}

	/**
	 * The setData method 
	 * @param data
	 */
	public void setData(T data) 
	{
		this.data = data;
	}

	/**
	 * The getData method
	 * @return the data within the TreeNode
	 */
	public T getData()
	{
		return data;
	}
}

