package treenode;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MorseCodeConverterTestSTUDENT
{
   File inputFile;
  
   File inputFileSTUDENT;

   @Before
   public void setUp() throws Exception  {     }

   @After
   public void tearDown() throws Exception {    }

   @Test
   public void StudentTestConvertToEnglishString() 
   {  
       String MorseToEng = MorseCodeConverter.convertToEnglish(".. / .- -- / -.-- --- -. .- ... ");
       assertEquals("i am yonas", MorseToEng);
       
       String MorseToEng2 = MorseCodeConverter.convertToEnglish(".-. . -.. . . -- . -.. / --- -. . ");
       assertEquals("redeemed one", MorseToEng2);
   }
   
   @Test
   public void testConvertToEnglishString2() 
   {  
       String test2="who you say i am";      
       String MorseToEng2 = MorseCodeConverter.convertToEnglish(".-- .... --- / -.-- --- ..- / ... .- -.-- / .. / .- -- ");
       assertTrue(test2.equals(MorseToEng2));    
   }
   
   @Test
   public void testPrintTree()
   {
       String allMorseCodeResult = "h s v i f u e l r a p w j  b d x n c k y t z g q m o";
       
       String temp = MorseCodeConverter.printTree();
       temp = temp.trim(); 
       System.out.println(temp);
       assertTrue(allMorseCodeResult.equals(temp));
   }
 }