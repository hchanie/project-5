package treenode;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MorseCodeTreeTestSTUDENT {
  
   MorseCodeTree studentTestTree = new MorseCodeTree();

   @Before
   public void setUp() throws Exception   {    }

   @After
   public void tearDown() throws Exception  
   {  
	   studentTestTree = null;
   }
   
   @Test
   public void studentTestGetRoot() 
   {   
       String rootTree;      
       rootTree = studentTestTree.getRoot().getData(); 
       assertTrue(rootTree.equals(rootTree));
   }
   
   @Test
   public void studentTestInsert()
   {    
	   //Inserting A Morse code for digit and check if it inserted correctly 
	   studentTestTree.insert(".....", "5");
       String characterFetched = studentTestTree.fetch(".....");    
       assertEquals("5", characterFetched);
       
     //Inserting A Morse code for the '&' Character and check if it inserted correctly 
       studentTestTree.insert(".-...", "&");
       String characterFetched2 = studentTestTree.fetch(".-...");    
       assertEquals("&", characterFetched2); 
   }

   @Test
   public void studentTestSetRoot()
   {            
       String newRootTree;
       assertEquals("", studentTestTree.getRoot().getData());
      
       // Create a new node, which will be use to set as the new root
       TreeNode<String> studentName = new TreeNode <String> ("Yonas");
      
       // Set the root to be the new node that was created
       studentTestTree.setRoot(studentName);
      
       newRootTree = studentTestTree.getRoot().getData();
      
       assertEquals("Yonas", newRootTree);
      // assertTrue(studentName.equals(newRootTree));
   }

   @Test
   public void studentTestSetRoot2()
   {      
	   String newRootTree;
	   
       // Create a new node and set it to be root
       TreeNode<String> studentName = new TreeNode <String> ("Yonas");
       studentTestTree.setRoot(studentName);     
       newRootTree = studentTestTree.getRoot().getData();
      
       assertEquals("Yonas", newRootTree);
   }
   
   @Test
   public void studentTestFetch() 
   {  
	  // "-.--" is the Morse code for the letter y.
       String characterFetched;
       characterFetched = studentTestTree.fetch("-.--"); 
       assertTrue(characterFetched.equals("y"));
       
       // "---" is the morse code for the letter o.
       String characterFetched1;
       characterFetched1 = studentTestTree.fetch("---");
       assertTrue(characterFetched1.equals("o"));
    
       // "-." is the morse code for the letter n.
       String characterFetched2;
       characterFetched2 = studentTestTree.fetch("-.");
       assertTrue(characterFetched2.equals("n"));
   }
   
   @Test
   public void studentTestToArrayList() 
   {
       ArrayList<String> StidentTreeList = new ArrayList<String>();
      
       StidentTreeList = studentTestTree.toArrayList();
      
       assertEquals("",  StidentTreeList.get(13));
       assertTrue(StidentTreeList.get(0).equals("h"));
       assertTrue(StidentTreeList.get(1).equals("s"));
       assertTrue(StidentTreeList.get(2).equals("v"));
       assertTrue(StidentTreeList.get(3).equals("i"));
       assertTrue(StidentTreeList.get(4).equals("f"));
       assertTrue(StidentTreeList.get(5).equals("u"));
       assertTrue(StidentTreeList.get(6).equals("e"));
       assertTrue(StidentTreeList.get(7).equals("l"));
       assertTrue(StidentTreeList.get(8).equals("r"));
       assertTrue(StidentTreeList.get(9).equals("a"));
       assertTrue(StidentTreeList.get(10).equals("p"));
       assertTrue(StidentTreeList.get(11).equals("w"));
       assertTrue(StidentTreeList.get(12).equals("j"));
       assertTrue(StidentTreeList.get(13).equals(""));
       assertTrue(StidentTreeList.get(14).equals("b"));
       assertTrue(StidentTreeList.get(15).equals("d"));
       assertTrue(StidentTreeList.get(16).equals("x"));
       assertTrue(StidentTreeList.get(17).equals("n"));
       assertTrue(StidentTreeList.get(18).equals("c"));
       assertTrue(StidentTreeList.get(19).equals("k"));
       assertTrue(StidentTreeList.get(20).equals("y"));
       assertTrue(StidentTreeList.get(21).equals("t"));
       assertTrue(StidentTreeList.get(22).equals("z"));
       assertTrue(StidentTreeList.get(23).equals("g"));
       assertTrue(StidentTreeList.get(24).equals("q"));
       assertTrue(StidentTreeList.get(25).equals("m"));
       assertTrue(StidentTreeList.get(26).equals("o")); 
   }
   
   @Test
   public void studentTestToArrayList2() 
   {
       ArrayList<String> StidentTreeList = new ArrayList<String>();
      
       StidentTreeList = studentTestTree.toArrayList();
      
       assertEquals("",  StidentTreeList.get(13));
       assertEquals("o",  StidentTreeList.get(26));
       assertEquals("a",  StidentTreeList.get(9));
   }
}

